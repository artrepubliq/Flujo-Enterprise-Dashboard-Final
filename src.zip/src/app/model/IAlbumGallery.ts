export interface IAlbumGallery{
    id: string;
    client_id: string;
    image: object;
    submitted_at: string;
    title: string;
}