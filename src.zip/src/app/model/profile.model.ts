export interface IProfileData{

    company_name: string;
    website_url: string;
    mobile_number: number;
    avatar: string;
}