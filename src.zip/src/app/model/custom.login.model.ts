export interface IcustomLoginModelDetails{
    access_token:string;
    result:string;
    status?:boolean;
    user_name:string;
}