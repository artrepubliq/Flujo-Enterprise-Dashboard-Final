export interface IHttpResponse{
    error?: string;
    result?: string;
}