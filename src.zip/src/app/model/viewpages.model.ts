export interface IViewPages{
    
}