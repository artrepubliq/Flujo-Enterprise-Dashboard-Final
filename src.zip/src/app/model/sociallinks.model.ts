export interface ISocialLinks{
    id: string;
    client_id: string;
    socialitem_name: string;
    socialitem_url: string;
}