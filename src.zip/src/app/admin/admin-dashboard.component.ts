import { Component } from '@angular/core';

@Component({
  template:  `
    
    <app-profile></app-profile>
  `
})
export class AdminDashboardComponent { }