export class AppConstants {
    public static get API_URL(): string { return "http://flujo.in/dashboard/flujo.in_api_client/"; };
    public static get CLIENT_ID(): string { return "1232"; };
    
  }